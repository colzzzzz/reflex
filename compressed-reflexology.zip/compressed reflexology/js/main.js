/**
 * Reflexology Website - Interactive Animations & Behaviors
 * Powered by GSAP & ScrollTrigger
 */

document.addEventListener('DOMContentLoaded', () => {
  // Register GSAP Plugins
  if (typeof gsap !== 'undefined') {
    if (typeof ScrollTrigger !== 'undefined') {
      gsap.registerPlugin(ScrollTrigger);
    }
    initHeroAnimations();
    initScrollAnimations();
  }

  initNavigation();
  initBookingInteractions();
});

/**
 * 1. Hero Section Animations
 * Smooth fade-in and slide-up on page load as specified in blueprint
 */
function initHeroAnimations() {
  const tl = gsap.timeline({
    defaults: { ease: 'power3.out', duration: 1.1 }
  });

  // Staggered entrance for hero elements
  tl.from('#hero-badge', {
    y: 20,
    opacity: 0,
    duration: 0.8,
    delay: 0.2
  })
  .from('#hero-headline', {
    y: 40,
    opacity: 0,
    duration: 1.2,
    ease: 'power4.out'
  }, '-=0.5')
  .from('#hero-subheadline', {
    y: 30,
    opacity: 0,
    duration: 1.0
  }, '-=0.8')
  .from('#hero-actions', {
    y: 25,
    opacity: 0,
    duration: 0.9
  }, '-=0.7')
  .from('#hero-stats', {
    y: 20,
    opacity: 0,
    duration: 0.8
  }, '-=0.6')
  .from('#hero-scroll-indicator', {
    opacity: 0,
    y: -10,
    duration: 0.8
  }, '-=0.4');

  // Gentle floating animation for background ambient glow orbs
  gsap.to('.ambient-glow-1', {
    y: 30,
    x: -20,
    duration: 8,
    repeat: -1,
    yoyo: true,
    ease: 'sine.inOut'
  });

  gsap.to('.ambient-glow-2', {
    y: -25,
    x: 25,
    duration: 9,
    repeat: -1,
    yoyo: true,
    ease: 'sine.inOut'
  });
}

/**
 * 2. Scroll-triggered animations for Experience and Services sections
 */
function initScrollAnimations() {
  if (typeof ScrollTrigger === 'undefined') return;

  // Experience Section text reveals smoothly on scroll
  const experienceElements = gsap.utils.toArray('.reveal-on-scroll');
  experienceElements.forEach((el, index) => {
    gsap.from(el, {
      scrollTrigger: {
        trigger: el,
        start: 'top 85%',
        toggleActions: 'play none none none'
      },
      y: 35,
      opacity: 0,
      duration: 1,
      ease: 'power3.out',
      delay: (index % 3) * 0.15
    });
  });

  // Services & Pricing Cards Staggered Reveal
  gsap.from('.service-card', {
    scrollTrigger: {
      trigger: '#services-container',
      start: 'top 80%',
      toggleActions: 'play none none none'
    },
    y: 50,
    opacity: 0,
    duration: 0.9,
    stagger: 0.18,
    ease: 'power3.out'
  });

  // Booking Section Reveal
  gsap.from('#booking-container', {
    scrollTrigger: {
      trigger: '#booking',
      start: 'top 80%',
      toggleActions: 'play none none none'
    },
    y: 40,
    opacity: 0,
    duration: 1,
    ease: 'power3.out'
  });
}

/**
 * 3. Navigation Bar Behavior
 * Sticky frosted-glass enhancement on scroll & mobile toggle
 */
function initNavigation() {
  const navbar = document.getElementById('navbar');
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');

  // Change navbar appearance slightly after scrolling down
  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      navbar.classList.add('scrolled', 'shadow-sm');
    } else {
      navbar.classList.remove('scrolled', 'shadow-sm');
    }
  });

  // Mobile menu toggle
  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', () => {
      const isOpen = !mobileMenu.classList.contains('hidden');
      if (isOpen) {
        mobileMenu.classList.add('hidden');
      } else {
        mobileMenu.classList.remove('hidden');
      }
    });

    // Close mobile menu on link click
    mobileMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mobileMenu.classList.add('hidden');
      });
    });
  }
}

/**
 * 4. Booking & Interactive Services Connection
 */
function initBookingInteractions() {
  // Connect "Select Treatment" buttons to form select field
  const serviceButtons = document.querySelectorAll('.select-service-btn');
  const treatmentSelect = document.getElementById('treatment-select');

  serviceButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const serviceName = btn.getAttribute('data-service');
      if (treatmentSelect && serviceName) {
        treatmentSelect.value = serviceName;
      }
      
      // Smooth scroll to booking
      const bookingSection = document.getElementById('booking');
      if (bookingSection) {
        bookingSection.scrollIntoView({ behavior: 'smooth' });
        // Highlight select field briefly
        treatmentSelect.classList.add('ring-2', 'ring-purple-600');
        setTimeout(() => {
          treatmentSelect.classList.remove('ring-2', 'ring-purple-600');
        }, 1500);
      }
    });
  });

  // Set minimum date for booking to today
  const dateInput = document.getElementById('date-input');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
  }

  // Handle Booking Form Submission
  const bookingForm = document.getElementById('booking-form');
  const bookingSuccess = document.getElementById('booking-success');
  const bookingDetailsMsg = document.getElementById('booking-success-details');

  if (bookingForm && bookingSuccess) {
    bookingForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const name = document.getElementById('name-input')?.value || 'Guest';
      const treatment = document.getElementById('treatment-select')?.value || 'Treatment';
      const date = document.getElementById('date-input')?.value || 'Upcoming date';
      
      if (bookingDetailsMsg) {
        bookingDetailsMsg.textContent = `Thank you, ${name}. Your appointment request for ${treatment} on ${date} has been received. Our team will contact you shortly to confirm your bespoke session.`;
      }

      // Hide form and show success state
      bookingForm.classList.add('hidden');
      bookingSuccess.classList.remove('hidden');

      // Scroll smoothly to success message
      bookingSuccess.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }

  // Allow resetting form if user wants to book another session
  const resetBtn = document.getElementById('book-another-btn');
  if (resetBtn && bookingForm && bookingSuccess) {
    resetBtn.addEventListener('click', () => {
      bookingForm.reset();
      bookingSuccess.classList.add('hidden');
      bookingForm.classList.remove('hidden');
    });
  }
}
